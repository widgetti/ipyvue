export function myimport(url) {
    return import(/* webpackIgnore: true */url);
}