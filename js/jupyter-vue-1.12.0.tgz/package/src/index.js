export { default as Vue } from './VueWithCompiler';
export { VueModel } from './VueModel';
export { VueTemplateModel } from './VueTemplateModel';
export { VueView, createViewContext } from './VueView';
export { HtmlModel } from './Html';
export { TemplateModel } from './Template';
export { ModuleModel } from './Module';
export { ForceLoadModel } from './ForceLoad';
export { vueRender } from './VueRenderer';
export { VueComponentModel } from './VueComponentModel';

export const { version } = require('../package.json'); // eslint-disable-line global-require
